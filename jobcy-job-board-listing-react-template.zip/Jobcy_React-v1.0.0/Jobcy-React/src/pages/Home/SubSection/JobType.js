import React from 'react'

const JobType = () => {
    return (
        <React.Fragment>
            <option value="4">Accounting</option>
            <option value="1">IT & Software</option>
            <option value="3">Marketing</option>
            <option value="5">Banking</option>
        </React.Fragment>
    )
}

export default JobType;
